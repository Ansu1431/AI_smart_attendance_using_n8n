document.addEventListener('DOMContentLoaded', () => {
  const video = document.getElementById('video');
  const verifyBtn = document.getElementById('verify');
  const result = document.getElementById('result');
  const studentDetails = document.getElementById('studentDetails');
  const studentMeta = document.getElementById('studentMeta');
  const marksTable = document.getElementById('marksTable');

  if (!video || !verifyBtn || !result) {
    return;
  }

  const showResult = (message, isSuccess) => {
    result.classList.remove('d-none');
    result.classList.toggle('alert-success', isSuccess);
    result.classList.toggle('alert-danger', !isSuccess);
    result.textContent = message;
  };

  const clearStudentDetails = () => {
    if (studentDetails) {
      studentDetails.classList.add('d-none');
    }
    if (studentMeta) {
      studentMeta.textContent = '';
    }
    if (marksTable) {
      marksTable.innerHTML = '';
    }
  };

  const renderStudentDetails = (data) => {
    if (!studentDetails || !studentMeta || !marksTable) {
      return;
    }

    const student = data.student || {};
    const attendance = data.attendance || {};
    const marks = Array.isArray(data.marks) ? data.marks : [];

    const attendanceText = attendance.last_seen
      ? `Attendance count: ${attendance.count}. Last seen: ${attendance.last_seen.date} ${attendance.last_seen.time}.`
      : `Attendance count: ${attendance.count || 0}.`;

    studentMeta.textContent = `${student.name || data.name} | ${attendanceText}`;

    if (!marks.length) {
      marksTable.innerHTML = '<tr><td colspan="5" class="text-white-60">No marks recorded yet.</td></tr>';
    } else {
      marksTable.innerHTML = marks
        .map(
          (mark) => `
            <tr>
              <td>${mark.subject}</td>
              <td>${mark.exam_type}</td>
              <td>${mark.term}</td>
              <td>${mark.score}</td>
              <td>${mark.max_score}</td>
            </tr>
          `
        )
        .join('');
    }

    studentDetails.classList.remove('d-none');
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: false
      });
      video.srcObject = stream;
    } catch (error) {
      const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
      const hint = isLocalhost
        ? 'Please allow camera access in your browser.'
        : 'Camera access requires HTTPS or localhost.';
      showResult(`Camera error: ${error.message}. ${hint}`, false);
    }
  };

  const captureFrame = () => {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.9);
  };

  verifyBtn.addEventListener('click', async () => {
    if (!video.srcObject) {
      showResult('Camera is not ready yet. Please allow access and try again.', false);
      return;
    }

    verifyBtn.disabled = true;
    verifyBtn.textContent = 'Verifying...';

    try {
      const image = captureFrame();
      const response = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Verification failed.');
      }

      if (data.match) {
        showResult(`Verified: ${data.name}. Attendance recorded.`, true);
        renderStudentDetails(data);
      } else {
        clearStudentDetails();
        showResult('Face not recognized. Please try again.', false);
      }
    } catch (error) {
      clearStudentDetails();
      showResult(error.message, false);
    } finally {
      verifyBtn.disabled = false;
      verifyBtn.innerHTML = '<i class="fas fa-check-circle me-2"></i>Verify & Mark Attendance';
    }
  });

  startCamera();
});
