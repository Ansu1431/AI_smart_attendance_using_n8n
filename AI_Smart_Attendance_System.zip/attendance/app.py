from flask import Flask, request, render_template, jsonify, redirect, url_for, session, send_from_directory, flash
from flask_mail import Mail, Message
import os
import io
import base64
import glob
import numpy as np
import sqlite3
import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from itsdangerous import URLSafeTimedSerializer
import secrets

# Try to import face_recognition; if not available, fall back to image-hash based matching
try:
    import face_recognition
    FACE_RECOG_AVAILABLE = True
except Exception as _e:
    FACE_RECOG_AVAILABLE = False
    print('face_recognition not available, falling back to image-hash matcher:', _e)
    from PIL import Image
    import imagehash

from PIL import Image as PILImage

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET', 'change-me')

# Define paths first
BASE_DIR = os.path.dirname(__file__)
PASSWORD_FILE = os.path.join(BASE_DIR, '.admin_password')
DB_PATH = os.path.join(BASE_DIR, 'data', 'attendance.db')
# n8n webhook URLs – read from email_config.py first, fall back to env vars
def _load_n8n_webhooks():
    marks = os.environ.get('N8N_MARKS_WEBHOOK', '').strip()
    alert = os.environ.get('N8N_ALERT_WEBHOOK', '').strip()
    try:
        import email_config as _cfg
        if not marks:
            marks = getattr(_cfg, 'N8N_MARKS_WEBHOOK', '').strip()
        if not alert:
            alert = getattr(_cfg, 'N8N_ALERT_WEBHOOK', '').strip()
    except ImportError:
        try:
            import sys as _sys
            _cfg_path = os.path.join(os.path.dirname(__file__), 'config')
            if _cfg_path not in _sys.path:
                _sys.path.insert(0, _cfg_path)
            import email_config as _cfg2
            if not marks:
                marks = getattr(_cfg2, 'N8N_MARKS_WEBHOOK', '').strip()
            if not alert:
                alert = getattr(_cfg2, 'N8N_ALERT_WEBHOOK', '').strip()
        except ImportError:
            pass
    return marks, alert

N8N_MARKS_WEBHOOK, N8N_ALERT_WEBHOOK = _load_n8n_webhooks()
print(f"[n8n] Marks webhook : {N8N_MARKS_WEBHOOK or '(not set)'}")
print(f"[n8n] Alert webhook : {N8N_ALERT_WEBHOOK or '(not set)'}")
LOW_PERFORMANCE_THRESHOLD = 0.40  # 40% threshold for marks and attendance alerts

# Simple admin password (replace or set env var ADMIN_PASSWORD in production)
# Check for password file first, then env var, then default
def get_admin_password():
    if os.path.exists(PASSWORD_FILE):
        try:
            with open(PASSWORD_FILE, 'r') as f:
                return f.read().strip()
        except:
            pass
    return os.environ.get('ADMIN_PASSWORD', 'admin123')

def save_admin_password(password):
    """Save admin password to file"""
    try:
        with open(PASSWORD_FILE, 'w') as f:
            f.write(password.strip())
        return True
    except Exception as e:
        print(f'Error saving password: {e}')
        return False

ADMIN_PASSWORD = get_admin_password()

# Try to load from config file first, then environment variables
# Check root directory first (for backward compatibility), then config directory
try:
    # Try root directory first
    import email_config as email_cfg
    ADMIN_EMAIL = getattr(email_cfg, 'ADMIN_EMAIL', os.environ.get('ADMIN_EMAIL', 'admin@example.com'))
    ADMIN_NAME = getattr(email_cfg, 'ADMIN_NAME', os.environ.get('ADMIN_NAME', 'Admin'))
    app.config['MAIL_SERVER'] = getattr(email_cfg, 'MAIL_SERVER', os.environ.get('MAIL_SERVER', 'smtp.gmail.com'))
    app.config['MAIL_PORT'] = int(getattr(email_cfg, 'MAIL_PORT', os.environ.get('MAIL_PORT', 587)))
    app.config['MAIL_USE_TLS'] = getattr(email_cfg, 'MAIL_USE_TLS', True) if hasattr(email_cfg, 'MAIL_USE_TLS') else (os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true')
    app.config['MAIL_USE_SSL'] = getattr(email_cfg, 'MAIL_USE_SSL', False) if hasattr(email_cfg, 'MAIL_USE_SSL') else (os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true')
    app.config['MAIL_USERNAME'] = getattr(email_cfg, 'MAIL_USERNAME', os.environ.get('MAIL_USERNAME', ''))
    app.config['MAIL_PASSWORD'] = getattr(email_cfg, 'MAIL_PASSWORD', os.environ.get('MAIL_PASSWORD', ''))
    app.config['MAIL_DEFAULT_SENDER'] = getattr(email_cfg, 'MAIL_DEFAULT_SENDER', os.environ.get('MAIL_DEFAULT_SENDER', ADMIN_EMAIL))
    print("[OK] Email configuration loaded from email_config.py")
except ImportError:
    # Try config directory
    try:
        import sys
        config_path = os.path.join(BASE_DIR, 'config')
        if config_path not in sys.path:
            sys.path.insert(0, config_path)
        import email_config as email_cfg
        ADMIN_EMAIL = getattr(email_cfg, 'ADMIN_EMAIL', os.environ.get('ADMIN_EMAIL', 'admin@example.com'))
        ADMIN_NAME = getattr(email_cfg, 'ADMIN_NAME', os.environ.get('ADMIN_NAME', 'Admin'))
        app.config['MAIL_SERVER'] = getattr(email_cfg, 'MAIL_SERVER', os.environ.get('MAIL_SERVER', 'smtp.gmail.com'))
        app.config['MAIL_PORT'] = int(getattr(email_cfg, 'MAIL_PORT', os.environ.get('MAIL_PORT', 587)))
        app.config['MAIL_USE_TLS'] = getattr(email_cfg, 'MAIL_USE_TLS', True) if hasattr(email_cfg, 'MAIL_USE_TLS') else (os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true')
        app.config['MAIL_USE_SSL'] = getattr(email_cfg, 'MAIL_USE_SSL', False) if hasattr(email_cfg, 'MAIL_USE_SSL') else (os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true')
        app.config['MAIL_USERNAME'] = getattr(email_cfg, 'MAIL_USERNAME', os.environ.get('MAIL_USERNAME', ''))
        app.config['MAIL_PASSWORD'] = getattr(email_cfg, 'MAIL_PASSWORD', os.environ.get('MAIL_PASSWORD', ''))
        app.config['MAIL_DEFAULT_SENDER'] = getattr(email_cfg, 'MAIL_DEFAULT_SENDER', os.environ.get('MAIL_DEFAULT_SENDER', ADMIN_EMAIL))
        print("[OK] Email configuration loaded from config/email_config.py")
    except ImportError:
        # Fall back to environment variables
        ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'admin@example.com')
        ADMIN_NAME = os.environ.get('ADMIN_NAME', 'Admin')
        app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
        app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
        app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
        app.config['MAIL_USE_SSL'] = os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true'
        app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
        app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
        app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', ADMIN_EMAIL)
        print("[INFO] Using environment variables for email configuration (or create email_config.py)")
    except ImportError:
        # Fall back to environment variables
        ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'admin@example.com')
        ADMIN_NAME = os.environ.get('ADMIN_NAME', 'Admin')
        app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
        app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
        app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
        app.config['MAIL_USE_SSL'] = os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true'
        app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
        app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
        app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', ADMIN_EMAIL)
        print("[INFO] Using environment variables for email configuration (or create email_config.py)")
except ImportError:
    # Fall back to environment variables
    ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'admin@example.com')
    ADMIN_NAME = os.environ.get('ADMIN_NAME', 'Admin')
    app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
    app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
    app.config['MAIL_USE_SSL'] = os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true'
    app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
    app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
    app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', ADMIN_EMAIL)
    print("[INFO] Using environment variables for email configuration (or create email_config.py)")

# Initialize Flask-Mail
mail = Mail(app)

# Token serializer for password reset
serializer = URLSafeTimedSerializer(app.secret_key)

IMAGES_DIR = os.path.join(BASE_DIR, 'static', 'images')
ATTENDANCE_CSV = os.path.join(BASE_DIR, 'data', 'attendance.csv')


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db_connection()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            student_email TEXT,
            parent_email TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS marks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            exam_type TEXT NOT NULL,
            term INTEGER NOT NULL,
            score REAL NOT NULL,
            max_score REAL NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(student_id) REFERENCES students(id)
        )
        """
    )
    conn.commit()
    conn.close()


def ensure_student(name: str) -> int:
    conn = get_db_connection()
    row = conn.execute("SELECT id FROM students WHERE name = ?", (name,)).fetchone()
    if row:
        conn.close()
        return row["id"]
    cur = conn.execute("INSERT INTO students (name) VALUES (?)", (name,))
    conn.commit()
    student_id = cur.lastrowid
    conn.close()
    return student_id


def get_student_profile(name: str):
    conn = get_db_connection()
    row = conn.execute(
        "SELECT id, name, student_email, parent_email FROM students WHERE name = ?",
        (name,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def update_student_profile(name: str, student_email: str, parent_email: str) -> int:
    student_id = ensure_student(name)
    conn = get_db_connection()
    conn.execute(
        "UPDATE students SET student_email = ?, parent_email = ? WHERE id = ?",
        (student_email, parent_email, student_id),
    )
    conn.commit()
    conn.close()
    return student_id


def add_student_mark(name: str, subject: str, exam_type: str, term: int, score: float, max_score: float):
    student_id = ensure_student(name)
    conn = get_db_connection()
    conn.execute(
        """
        INSERT INTO marks (student_id, subject, exam_type, term, score, max_score, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (student_id, subject, exam_type, term, score, max_score, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def get_student_marks(name: str):
    profile = get_student_profile(name)
    if not profile:
        return []
    conn = get_db_connection()
    rows = conn.execute(
        """
        SELECT id, subject, exam_type, term, score, max_score
        FROM marks
        WHERE student_id = ?
        ORDER BY exam_type, term, subject
        """,
        (profile["id"],),
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_attendance_summary(name: str):
    count = 0
    last_seen = None
    if os.path.exists(ATTENDANCE_CSV):
        try:
            with open(ATTENDANCE_CSV, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) >= 3 and parts[0] == name:
                        count += 1
                        last_seen = {"date": parts[1], "time": parts[2]}
        except Exception as e:
            print('Failed to read attendance:', e)
    return {"count": count, "last_seen": last_seen}


def get_total_attendance_days():
    """Return the number of unique class days recorded across all students."""
    dates = set()
    if os.path.exists(ATTENDANCE_CSV):
        try:
            with open(ATTENDANCE_CSV, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) >= 2 and parts[1]:
                        dates.add(parts[1])
        except Exception as e:
            print('Failed to read attendance days:', e)
    return len(dates)


def get_student_attendance_percentage(name: str):
    """Calculate a student's attendance percentage (attended / total class days)."""
    total_days = get_total_attendance_days()
    if total_days == 0:
        return None
    attended_dates = set()
    if os.path.exists(ATTENDANCE_CSV):
        try:
            with open(ATTENDANCE_CSV, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) >= 2 and parts[0] == name:
                        attended_dates.add(parts[1])
        except Exception:
            pass
    return len(attended_dates) / total_days


def get_student_marks_percentage(name: str):
    """Calculate a student's overall marks percentage across all recorded marks."""
    marks = get_student_marks(name)
    if not marks:
        return None
    total_score = sum(float(m['score']) for m in marks)
    total_max = sum(float(m['max_score']) for m in marks)
    return (total_score / total_max) if total_max > 0 else None


def check_and_send_low_performance_alert(name: str) -> dict:
    """Check if a student is below the 40% threshold and send alert email + n8n trigger."""
    profile = get_student_profile(name)
    if not profile:
        return {'sent': False, 'reason': 'student not found'}

    recipients = []
    if profile.get('student_email'):
        recipients.append(profile['student_email'])
    if profile.get('parent_email'):
        recipients.append(profile['parent_email'])
    if not recipients:
        return {'sent': False, 'reason': 'no email addresses on file'}

    marks_pct = get_student_marks_percentage(name)
    att_pct = get_student_attendance_percentage(name)

    alerts = []
    if marks_pct is not None and marks_pct < LOW_PERFORMANCE_THRESHOLD:
        alerts.append({'type': 'marks', 'percentage': round(marks_pct * 100, 1)})
    if att_pct is not None and att_pct < LOW_PERFORMANCE_THRESHOLD:
        alerts.append({'type': 'attendance', 'percentage': round(att_pct * 100, 1)})

    if not alerts:
        return {'sent': False, 'reason': 'performance above threshold'}

    # Trigger n8n outbound alert webhook if configured
    if N8N_ALERT_WEBHOOK:
        try:
            payload = json.dumps({
                'student': name,
                'student_email': profile.get('student_email', ''),
                'parent_email': profile.get('parent_email', ''),
                'alerts': alerts,
                'marks_percentage': round(marks_pct * 100, 1) if marks_pct is not None else None,
                'attendance_percentage': round(att_pct * 100, 1) if att_pct is not None else None,
                'threshold': int(LOW_PERFORMANCE_THRESHOLD * 100),
                'triggered_at': datetime.utcnow().isoformat(),
            }).encode('utf-8')
            req = urllib.request.Request(
                N8N_ALERT_WEBHOOK,
                data=payload,
                headers={'Content-Type': 'application/json'},
                method='POST',
            )
            urllib.request.urlopen(req, timeout=10)
            print(f'[n8n] Low-performance alert triggered for {name}')
        except Exception as e:
            print(f'[n8n alert webhook failed for {name}]: {e}')

    # Send email alert
    try:
        if not app.config.get('MAIL_USERNAME') or not app.config.get('MAIL_PASSWORD'):
            return {'sent': False, 'reason': 'email not configured', 'alerts': alerts}
        marks = get_student_marks(name)
        attendance_summary = get_attendance_summary(name)
        msg = Message(
            subject=f'⚠️ Low Performance Alert – {name}',
            recipients=recipients,
            html=render_template(
                'emails/email_low_performance.html',
                student=profile,
                marks=marks,
                attendance=attendance_summary,
                alerts=alerts,
                marks_percentage=round(marks_pct * 100, 1) if marks_pct is not None else None,
                attendance_percentage=round(att_pct * 100, 1) if att_pct is not None else None,
                threshold=int(LOW_PERFORMANCE_THRESHOLD * 100),
            ),
        )
        mail.send(msg)
        print(f'[Alert] Low-performance email sent for {name} → {recipients}')
        return {'sent': True, 'alerts': alerts, 'recipients': recipients}
    except Exception as e:
        print(f'[Alert email failed for {name}]: {e}')
        return {'sent': False, 'reason': str(e), 'alerts': alerts}


def build_ai_summary(name: str, marks, attendance_summary):
    if not marks:
        return f"{name} has no marks recorded yet. Attendance count: {attendance_summary['count']}."

    totals = {}
    for mark in marks:
        key = (mark["exam_type"], mark["term"])
        entry = totals.setdefault(key, {"score": 0.0, "max": 0.0})
        entry["score"] += float(mark["score"])
        entry["max"] += float(mark["max_score"])

    parts = []
    for (exam_type, term), agg in totals.items():
        percent = (agg["score"] / agg["max"] * 100) if agg["max"] else 0
        parts.append(f"{exam_type.title()} term {term}: {agg['score']:.1f}/{agg['max']:.1f} ({percent:.1f}%)")

    last_seen = attendance_summary.get("last_seen")
    last_text = ""
    if last_seen:
        last_text = f" Last attendance: {last_seen['date']} {last_seen['time']}."
    return f"{name}'s performance summary: " + "; ".join(parts) + f". Attendance count: {attendance_summary['count']}." + last_text


def sanitize_name(name: str) -> str:
    return "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip().replace(' ', '_')


def load_known_faces():
    """Load known faces. If face_recognition is available return name->encoding (np.array).
    Otherwise return name->imagehash object (phash)."""
    encodings = {}
    for path in glob.glob(os.path.join(IMAGES_DIR, '*')):
        if os.path.isfile(path):
            filename = os.path.basename(path)
            name, _ = os.path.splitext(filename)
            try:
                if FACE_RECOG_AVAILABLE:
                    img = face_recognition.load_image_file(path)
                    faces = face_recognition.face_encodings(img)
                    if faces:
                        encodings[name] = faces[0]
                else:
                    pil = PILImage.open(path).convert('RGB')
                    encodings[name] = imagehash.phash(pil)
            except Exception as e:
                print(f"Skipping {path}: {e}")
    return encodings


# Global cache of known faces
KNOWN_FACES = load_known_faces()
init_db()


def record_attendance(name: str):
    """Append an attendance record to CSV (name,date,time)."""
    try:
        ts = datetime.now()
        line = f'{name},{ts.date()},{ts.time().strftime("%H:%M:%S")}\n'
        with open(ATTENDANCE_CSV, 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception as e:
        print('Failed to record attendance:', e)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/admin')
def admin_login():
    return render_template('admin_login.html')


@app.route('/admin/login', methods=['POST'])
def do_admin_login():
    password = request.form.get('password', '')
    current_password = get_admin_password()
    if password == current_password:
        session['admin'] = True
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_login.html', error='Invalid password')


@app.route('/admin/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        
        # Check if email matches admin email
        if email.lower() == ADMIN_EMAIL.lower():
            # Generate reset token (valid for 1 hour)
            token = serializer.dumps(email, salt='password-reset-salt')
            reset_url = url_for('reset_password', token=token, _external=True)
            
            # Send email
            try:
                # Test email configuration
                if not app.config.get('MAIL_USERNAME') or not app.config.get('MAIL_PASSWORD'):
                    raise ValueError('Email username or password not configured')
                
                msg = Message(
                    subject='Password Reset Request - Attendance System',
                    recipients=[ADMIN_EMAIL],
                    html=render_template('emails/email_reset_password.html', 
                                       reset_url=reset_url, 
                                       admin_name=ADMIN_NAME,
                                       expiry_hours=1)
                )
                mail.send(msg)
                print(f"[SUCCESS] Password reset email sent to {ADMIN_EMAIL}")
                return render_template('forgot_password.html', 
                                     success='Password reset link has been sent to your email address. Please check your inbox.')
            except Exception as e:
                error_msg = str(e)
                print(f'[ERROR] Email sending failed: {error_msg}')
                print(f'[DEBUG] Mail config - Server: {app.config.get("MAIL_SERVER")}, Port: {app.config.get("MAIL_PORT")}')
                print(f'[DEBUG] Mail config - Username: {app.config.get("MAIL_USERNAME")}, TLS: {app.config.get("MAIL_USE_TLS")}')
                
                # Provide more helpful error message
                if 'authentication failed' in error_msg.lower() or 'invalid credentials' in error_msg.lower():
                    error_display = 'Email authentication failed. For Gmail, you need to use an App Password instead of your regular password. Please check EMAIL_SETUP.md for instructions.'
                elif '535' in error_msg or 'smtp' in error_msg.lower():
                    error_display = f'SMTP error: {error_msg}. Please verify your email credentials and SMTP settings.'
                else:
                    error_display = f'Failed to send email: {error_msg}. Please check your email configuration.'
                
                return render_template('forgot_password.html', error=error_display)
        else:
            # Don't reveal if email exists or not (security best practice)
            return render_template('forgot_password.html', 
                                 success='If the email address exists, a password reset link has been sent.')
    
    return render_template('forgot_password.html')


@app.route('/admin/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        # Verify token (valid for 1 hour)
        email = serializer.loads(token, salt='password-reset-salt', max_age=3600)
    except Exception as e:
        return render_template('reset_password.html', error='Invalid or expired reset link. Please request a new one.', invalid_token=True)
    
    if request.method == 'POST':
        new_password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        
        if not new_password:
            return render_template('reset_password.html', error='Password cannot be empty.', token=token)
        
        if new_password != confirm_password:
            return render_template('reset_password.html', error='Passwords do not match.', token=token)
        
        if len(new_password) < 6:
            return render_template('reset_password.html', error='Password must be at least 6 characters long.', token=token)
        
        # Update password
        if save_admin_password(new_password):
            global ADMIN_PASSWORD
            ADMIN_PASSWORD = new_password
            return render_template('reset_password.html', 
                                 success='Password has been successfully reset! You can now login with your new password.',
                                 token=None, reset_success=True)
        else:
            return render_template('reset_password.html', 
                                 error='Failed to save password. Please contact your system administrator.',
                                 token=token)
    
    if 'reset_success' in request.args:
        return render_template('reset_password.html', 
                             success='Password reset successful! You can now login with your new password.',
                             token=None, reset_success=True)
    return render_template('reset_password.html', token=token)


def _image_from_bytes(file_bytes):
    try:
        if FACE_RECOG_AVAILABLE:
            img = face_recognition.load_image_file(io.BytesIO(file_bytes))
            return img
        else:
            return PILImage.open(io.BytesIO(file_bytes)).convert('RGB')
    except Exception:
        return PILImage.open(io.BytesIO(file_bytes)).convert('RGB')


@app.route('/api/verify', methods=['POST'])
def api_verify():
    # Accept form-data file or JSON with base64 image
    file = request.files.get('image')
    img = None
    if file:
        img = _image_from_bytes(file.read())
    else:
        payload = request.get_json(silent=True) or {}
        b64 = payload.get('image')
        if b64:
            header, _, data = b64.partition(',')
            file_bytes = base64.b64decode(data or b64)
            img = _image_from_bytes(file_bytes)

    if img is None:
        return jsonify({'error': 'No image provided'}), 400

    # If face_recognition is available, use embeddings; otherwise use image-hash based approximate match
    if FACE_RECOG_AVAILABLE:
        faces = face_recognition.face_encodings(img)
        if not faces:
            return jsonify({'error': 'No face found'}), 400
        face = faces[0]
        names = list(KNOWN_FACES.keys())
        encs = list(KNOWN_FACES.values())
        if not encs:
            return jsonify({'error': 'No registered students'}), 400
        distances = face_recognition.face_distance(encs, face)
        best_idx = int(np.argmin(distances))
        match = distances[best_idx] < 0.5
        name = names[best_idx] if match else 'Unknown'
        if match:
            record_attendance(name)
            ensure_student(name)
        response = {'name': name, 'match': bool(match), 'distance': float(distances[best_idx])}
        if match:
            profile = get_student_profile(name)
            marks = get_student_marks(name)
            attendance_summary = get_attendance_summary(name)
            response.update({"student": profile, "marks": marks, "attendance": attendance_summary})
        return jsonify(response)
    else:
        # img is a PIL Image
        ph = imagehash.phash(img)
        best = None
        best_dist = 999
        for n, h in KNOWN_FACES.items():
            d = ph - h
            if d < best_dist:
                best_dist = d
                best = n
        if best is None:
            return jsonify({'error': 'No registered students'}), 400
        match = best_dist <= 10
        if match:
            record_attendance(best)
            ensure_student(best)
        response = {'name': best if match else 'Unknown', 'match': bool(match), 'distance': int(best_dist)}
        if match:
            profile = get_student_profile(best)
            marks = get_student_marks(best)
            attendance_summary = get_attendance_summary(best)
            response.update({"student": profile, "marks": marks, "attendance": attendance_summary})
        return jsonify(response)


@app.route('/api/admin/add_student', methods=['POST'])
def api_add_student():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '').strip()
    file = request.files.get('image')
    if not name:
        return jsonify({'error': 'name required'}), 400
    safe = sanitize_name(name)
    os.makedirs(IMAGES_DIR, exist_ok=True)
    if file:
        ext = os.path.splitext(file.filename)[1] or '.png'
        dest = os.path.join(IMAGES_DIR, f"{safe}{ext}")
        file.save(dest)
    else:
        # no uploaded file: copy placeholder image so student has a thumbnail
        placeholder = os.path.join(BASE_DIR, 'static', 'img', 'placeholder.png')
        dest = os.path.join(IMAGES_DIR, f"{safe}.png")
        try:
            if os.path.exists(placeholder):
                import shutil
                shutil.copyfile(placeholder, dest)
            else:
                # create a tiny blank image as fallback
                from PIL import Image as PILImg
                img = PILImg.new('RGB', (200, 200), color=(200, 200, 200))
                img.save(dest)
        except Exception as e:
            print('Failed to create placeholder image:', e)
    # reload
    global KNOWN_FACES
    KNOWN_FACES = load_known_faces()
    ensure_student(safe)
    return jsonify({'ok': True, 'students': list(KNOWN_FACES.keys())})


@app.route('/api/admin/update_student', methods=['POST'])
def api_update_student():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '').strip()
    student_email = request.form.get('student_email', '').strip()
    parent_email = request.form.get('parent_email', '').strip()
    if not name:
        return jsonify({'error': 'name required'}), 400
    update_student_profile(name, student_email, parent_email)
    return jsonify({'ok': True})


@app.route('/api/admin/add_mark', methods=['POST'])
def api_add_mark():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '').strip()
    subject = request.form.get('subject', '').strip()
    exam_type = request.form.get('exam_type', '').strip().lower()
    term = request.form.get('term', '').strip()
    score = request.form.get('score', '').strip()
    max_score = request.form.get('max_score', '').strip()
    if not name or not subject or not exam_type or not term or not score or not max_score:
        return jsonify({'error': 'all fields required'}), 400
    if exam_type not in ('sessional', 'semester'):
        return jsonify({'error': 'exam_type must be sessional or semester'}), 400
    try:
        term_val = int(term)
        score_val = float(score)
        max_val = float(max_score)
    except ValueError:
        return jsonify({'error': 'term, score, and max_score must be numeric'}), 400
    add_student_mark(name, subject, exam_type, term_val, score_val, max_val)
    # Automatically check and alert if student falls below 40% threshold
    alert_result = check_and_send_low_performance_alert(name)
    return jsonify({'ok': True, 'alert': alert_result})


@app.route('/api/admin/student_details')
def api_student_details():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.args.get('name', '').strip()
    if not name:
        return jsonify({'error': 'name required'}), 400
    profile = get_student_profile(name)
    marks = get_student_marks(name)
    attendance_summary = get_attendance_summary(name)
    return jsonify({'student': profile, 'marks': marks, 'attendance': attendance_summary})


@app.route('/api/admin/send_marks', methods=['POST'])
def api_send_marks():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '').strip()
    if not name:
        return jsonify({'error': 'name required'}), 400
    profile = get_student_profile(name)
    if not profile:
        return jsonify({'error': 'student not found'}), 404
    recipients = []
    if profile.get('parent_email'):
        recipients.append(profile['parent_email'])
    if profile.get('student_email'):
        recipients.append(profile['student_email'])
    if not recipients:
        return jsonify({'error': 'no recipient emails set for this student'}), 400

    marks = get_student_marks(name)
    attendance_summary = get_attendance_summary(name)
    summary = build_ai_summary(name, marks, attendance_summary)

    try:
        if not app.config.get('MAIL_USERNAME') or not app.config.get('MAIL_PASSWORD'):
            raise ValueError('Email username or password not configured')
        msg = Message(
            subject=f'Marks Summary - {name}',
            recipients=recipients,
            html=render_template(
                'emails/email_marks_summary.html',
                student=profile,
                marks=marks,
                attendance=attendance_summary,
                summary=summary,
            ),
        )
        mail.send(msg)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def sync_marks_from_webhook():
    if not N8N_MARKS_WEBHOOK:
        raise ValueError('N8N_MARKS_WEBHOOK is not configured')

    try:
        with urllib.request.urlopen(N8N_MARKS_WEBHOOK, timeout=20) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
    except urllib.error.URLError as e:
        raise ValueError(f'Failed to reach webhook: {e}')
    except json.JSONDecodeError:
        raise ValueError('Webhook response is not valid JSON')

    students = payload.get('students', []) if isinstance(payload, dict) else []
    if not isinstance(students, list):
        raise ValueError('Webhook response must include a students array')

    conn = get_db_connection()
    conn.execute('DELETE FROM marks')
    student_count = 0
    mark_count = 0

    for student in students:
        if not isinstance(student, dict):
            continue
        name = str(student.get('name', '')).strip()
        if not name:
            continue
        student_email = str(student.get('student_email') or '').strip()
        parent_email = str(student.get('parent_email') or '').strip()

        row = conn.execute('SELECT id FROM students WHERE name = ?', (name,)).fetchone()
        if row:
            student_id = row['id']
            conn.execute(
                'UPDATE students SET student_email = ?, parent_email = ? WHERE id = ?',
                (student_email, parent_email, student_id),
            )
        else:
            cur = conn.execute(
                'INSERT INTO students (name, student_email, parent_email) VALUES (?, ?, ?)',
                (name, student_email, parent_email),
            )
            student_id = cur.lastrowid
        student_count += 1

        marks = student.get('marks', []) if isinstance(student, dict) else []
        for mark in marks:
            if not isinstance(mark, dict):
                continue
            subject = str(mark.get('subject', '')).strip()
            exam_type = str(mark.get('exam_type', '')).strip().lower()
            if exam_type == 'seasonal':
                exam_type = 'sessional'
            if not subject or exam_type not in ('sessional', 'semester'):
                continue
            try:
                term = int(mark.get('term', 1))
                score = float(mark.get('score', 0))
                max_score = float(mark.get('max_score', 0))
            except (TypeError, ValueError):
                continue
            conn.execute(
                """
                INSERT INTO marks (student_id, subject, exam_type, term, score, max_score, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (student_id, subject, exam_type, term, score, max_score, datetime.utcnow().isoformat()),
            )
            mark_count += 1

    conn.commit()
    conn.close()

    # After sync, auto-check all synced students for low performance and send alerts
    alert_count = 0
    synced_names = [s.get('name', '').strip() for s in students if isinstance(s, dict) and s.get('name', '').strip()]
    for sname in synced_names:
        result = check_and_send_low_performance_alert(sname)
        if result.get('sent'):
            alert_count += 1

    return {
        'students': student_count,
        'marks': mark_count,
        'alerts_sent': alert_count,
        'synced_at': datetime.utcnow().isoformat()
    }


@app.route('/api/admin/sync_marks')
def api_sync_marks():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    try:
        result = sync_marks_from_webhook()
        return jsonify({'ok': True, **result})
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/admin/remove_student', methods=['POST'])
def api_remove_student():
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '')
    if not name:
        return jsonify({'error': 'name required'}), 400
    safe = sanitize_name(name)
    removed = False
    for path in glob.glob(os.path.join(IMAGES_DIR, f"{safe}.*")):
        try:
            os.remove(path)
            removed = True
        except Exception as e:
            print('remove error', e)
    global KNOWN_FACES
    KNOWN_FACES = load_known_faces()
    return jsonify({'ok': True, 'removed': removed, 'students': list(KNOWN_FACES.keys())})


@app.route('/api/admin/check_alerts', methods=['POST'])
def api_check_alerts():
    """Manually trigger low-performance checks for all students or a specific one."""
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    name = request.form.get('name', '').strip()
    conn = get_db_connection()
    if name:
        student_names = [name]
    else:
        rows = conn.execute('SELECT name FROM students').fetchall()
        student_names = [r['name'] for r in rows]
    conn.close()

    results = []
    alerts_sent = 0
    for sname in student_names:
        marks_pct = get_student_marks_percentage(sname)
        att_pct = get_student_attendance_percentage(sname)
        result = check_and_send_low_performance_alert(sname)
        if result.get('sent'):
            alerts_sent += 1
        results.append({
            'name': sname,
            'marks_percentage': round(marks_pct * 100, 1) if marks_pct is not None else None,
            'attendance_percentage': round(att_pct * 100, 1) if att_pct is not None else None,
            'below_threshold': bool(result.get('alerts')),
            'alert_sent': result.get('sent', False),
        })
    return jsonify({'ok': True, 'checked': len(results), 'alerts_sent': alerts_sent, 'results': results})


@app.route('/api/admin/performance_summary')
def api_performance_summary():
    """Return performance summary for all students (marks %, attendance %)."""
    if not session.get('admin'):
        return jsonify({'error': 'unauthorized'}), 401
    conn = get_db_connection()
    rows = conn.execute('SELECT name FROM students').fetchall()
    conn.close()
    summary = []
    for row in rows:
        sname = row['name']
        marks_pct = get_student_marks_percentage(sname)
        att_pct = get_student_attendance_percentage(sname)
        summary.append({
            'name': sname,
            'marks_percentage': round(marks_pct * 100, 1) if marks_pct is not None else None,
            'attendance_percentage': round(att_pct * 100, 1) if att_pct is not None else None,
            'marks_below_threshold': (marks_pct is not None and marks_pct < LOW_PERFORMANCE_THRESHOLD),
            'attendance_below_threshold': (att_pct is not None and att_pct < LOW_PERFORMANCE_THRESHOLD),
        })
    return jsonify({'ok': True, 'threshold': int(LOW_PERFORMANCE_THRESHOLD * 100), 'students': summary})


@app.route('/images/<path:filename>')
def serve_image(filename):
    # Serve images from the images directory
    return send_from_directory(IMAGES_DIR, filename)


def read_attendance():
    rows = []
    if os.path.exists(ATTENDANCE_CSV):
        try:
            with open(ATTENDANCE_CSV, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) >= 3:
                        rows.append({'name': parts[0], 'date': parts[1], 'time': parts[2]})
        except Exception as e:
            print('Failed to read attendance:', e)
    return rows


@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    # Build student list from actual files in IMAGES_DIR so we can show correct extensions
    students = []
    for path in sorted(glob.glob(os.path.join(IMAGES_DIR, '*'))):
        if os.path.isfile(path):
            filename = os.path.basename(path)
            name, _ext = os.path.splitext(filename)
            students.append({'name': name, 'filename': filename})
    attendance = read_attendance()
    return render_template('admin_dashboard.html', students=students, attendance=attendance)


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

